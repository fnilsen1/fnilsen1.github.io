//handout oving 2

#include "std_lib_facilities.h"
#include "AnimationWindow.h"


// void inputAndPrintInteger() {
//     // BEGIN: 1b

//     // END: 1b
// }

// int inputInteger() {
//     // BEGIN: 1c
//     return 0;
//     // END: 1c
// }

// void printSumOfInputIntegers() {
//     // BEGIN: 1d

//     // END: 1d
// }

// bool isOdd(int n) {
//     // BEGIN: 1f
//     return 0;
//     // END: 1f
// }

// void inputIntegersAndPrintSum() {
//     // BEGIN: 2a

//     // END: 2a
// }

// void inputIntegersAndPrintSumUntilStopped() {
//     // BEGIN: 2b

//     // END: 2b
// }

// double inputDouble() {
//     // BEGIN: 2d
//     return 0;
//     // END: 2d
// }

// void convertNOKtoEUR() {
//     // BEGIN: 2e

//     // END: 2e
// }

// void printMultiplicationTable() {
//     // BEGIN: 2g

//     // END: 2g
// }

// double discriminant(double a, double b, double c) {
//     // BEGIN: 3a
//     return 0;
//     // END: 3a
// }

// void printRealRoots(double a, double b, double c) {
//     // BEGIN: 3b

//     // END: 3b
// }

// void solveQuadraticEquations() {
//     // BEGIN: 3c

//     // END: 3c
// }

// void pythagoras() {
//     // BEGIN: 4a
//     // Alle deloppgaver i 4 skal løses her
//     // END: 4a
// }

// vector<int> calculateBalance(int amount, int rate, int years) {
//     // BEGIN: 5a
//     return {};
//     // END: 5a
// }

// void printBalance(vector<int> balanceVec) {
//     // BEGIN: 5b

//     // END: 5b
// }

int main() {
    // Oppgave 1a
    // Her kan du teste funksjonene dine ved hjelp av menysystem som beskrevet. 
    // NB: Denne delen av koden blir IKKE automatisk rettet.
vector<int> v = {1, 2, 3, 4, 5, 6, 7, 8, 9};
for (int i = 0; i < v.size(); i++) {
cout << v.at(i) << endl;
}
    return 0;
}
